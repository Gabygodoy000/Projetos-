-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           5.7.31 - MySQL Community Server (GPL)
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para tccredesocial
CREATE DATABASE IF NOT EXISTS `tccredesocial` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `tccredesocial`;

-- Copiando estrutura para tabela tccredesocial.comentarios
CREATE TABLE IF NOT EXISTS `comentarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `comentario` varchar(50) DEFAULT NULL,
  `id_post` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=107 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela tccredesocial.comentarios: 4 rows
/*!40000 ALTER TABLE `comentarios` DISABLE KEYS */;
INSERT INTO `comentarios` (`id`, `id_usuario`, `comentario`, `id_post`) VALUES
	(106, 127, 'lindão', 11),
	(104, 125, 'jogo todos os dia esse game', 10),
	(100, 128, 'eu tbm gosto dms', 8);
/*!40000 ALTER TABLE `comentarios` ENABLE KEYS */;

-- Copiando estrutura para tabela tccredesocial.comunidade
CREATE TABLE IF NOT EXISTS `comunidade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_criador` int(11) DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_comunidade_usuario` (`id_criador`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela tccredesocial.comunidade: 1 rows
/*!40000 ALTER TABLE `comunidade` DISABLE KEYS */;
INSERT INTO `comunidade` (`id`, `id_criador`, `nome`, `descricao`, `banner`) VALUES
	(9, 109, 'igor', 'salve #pc melhor que console', 'thumb-1920-838233.jpg');
/*!40000 ALTER TABLE `comunidade` ENABLE KEYS */;

-- Copiando estrutura para tabela tccredesocial.curtir
CREATE TABLE IF NOT EXISTS `curtir` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_post` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=163 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela tccredesocial.curtir: 2 rows
/*!40000 ALTER TABLE `curtir` DISABLE KEYS */;
/*!40000 ALTER TABLE `curtir` ENABLE KEYS */;

-- Copiando estrutura para tabela tccredesocial.games
CREATE TABLE IF NOT EXISTS `games` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game` varchar(255) DEFAULT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTmGGGghoeCIHGY6L7o3_Aw_WqQKhbgPxFjcgNT4v3y_nniDKJp1octSXVFLALQG4pTyEw&usqp=CAU',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela tccredesocial.games: 30 rows
/*!40000 ALTER TABLE `games` DISABLE KEYS */;
INSERT INTO `games` (`id`, `game`, `img`) VALUES
	(6, 'selecione um game', 'https://www.cebrac.com.br/view/img/cursos/criacao-games/criacao-games.jpg'),
	(8, 'Minecraft', 'https://play-lh.googleusercontent.com/yAtZnNL-9Eb5VYSsCaOC7KAsOVIJcY8mpKa0MoF-0HCL6b0OrFcBizURHywpuip-D6Y=w412-h220-rw'),
	(9, 'CS GO', 'https://midias.jb.com.br/_midias/jpg/2021/03/11/csgo-586394.jpg'),
	(10, 'Valorant', 'https://s2.glbimg.com/QWdLe0AOdvE1l-N5sLVsJhjurj4=/1200x/smart/filters:cover():strip_icc()/i.s3.glbimg.com/v1/AUTH_08fbf48bc0524877943fe86e43087e7a/internal_photos/bs/2020/j/U/iLO5YCRBmGHUsDwBIBHA/valorant-closed-beta-1200x675.png'),
	(11, 'Rust', 'https://www.cinehero.com.br/wp-content/uploads/2021/03/Rust.jpg'),
	(12, 'League of Legends', 'https://d2skuhm0vrry40.cloudfront.net/2021/articles/2021-07-16-18-20/league-of-legends-requisitos-minimos-lol-1626456007951.jpg/EG11/resize/1200x-1/league-of-legends-requisitos-minimos-lol-1626456007951.jpg'),
	(14, 'Free Fire', 'https://i.pinimg.com/originals/52/4c/fe/524cfe176b0d194ebb40edca252a7d1e.jpg'),
	(15, 'Roblox', 'https://s2.glbimg.com/eaKVAPmv0JNwKrQVXXw1WcZcQGU=/0x0:695x390/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_08fbf48bc0524877943fe86e43087e7a/internal_photos/bs/2020/q/H/YA7BdTRP25WBhC3SxE1w/roblox-game-pc-gratis-perguntas-respostas.jpg'),
	(16, 'Call of Duty: Warzone', 'https://upload.wikimedia.org/wikipedia/pt/thumb/e/e9/CallofDutyModernWarfare%282019%29.jpg/270px-CallofDutyModernWarfare%282019%29.jpg'),
	(17, 'PUBG', 'https://emc.acidadeon.com/dbimagens/pubg__1024x576_15072021151924.jpg'),
	(18, 'Apex Legends', 'https://upload.wikimedia.org/wikipedia/pt/thumb/a/ad/Apex_legends_capa.jpg/260px-Apex_legends_capa.jpg'),
	(19, 'Dota 2', 'https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota2_social.jpg'),
	(20, 'GTA V', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTmGGGghoeCIHGY6L7o3_Aw_WqQKhbgPxFjcgNT4v3y_nniDKJp1octSXVFLALQG4pTyEw&usqp=CAU'),
	(21, 'Warframe', 'https://s2.gaming-cdn.com/images/products/9466/orig/warframe-pc-jogo-steam-cover.jpg'),
	(22, 'Dead by Daylight\r\n', 'https://store-images.s-microsoft.com/image/apps.5904.13756572830160292.fc7dc0d8-9b57-4e22-ba0f-cb9eb13277cc.4feb3935-c0bf-4e50-ab06-2df5bd33c4bd?w=180&h=270&q=60'),
	(23, 'ARK: Survival Evolved', 'https://image.api.playstation.com/vulcan/img/rnd/202010/0818/HVUPJTyjOslwxbwCC8edPC45.png'),
	(24, 'Destiny 2', 'https://image.api.playstation.com/vulcan/img/rnd/202008/2201/M5krMe5G68NtiE81pkKHlRn6.png'),
	(25, 'Grand Chase', 'https://cdn.ome.lt/782RjKHsqX9h2H3UlLnD-8n9DEQ=/1200x630/smart/extras/conteudos/Grand-Chase.png'),
	(26, 'Rocket League', 'https://www.gamerpoint.com.br/wp-content/uploads/2020/09/rocket-league-free-to-play-.jpg'),
	(27, 'World of Tanks', 'https://cdn.cloudflare.steamstatic.com/steamcommunity/public/images/clans/39263509/bf9b969ec4acf760a0134bd0f5821bef482a7541.jpg'),
	(28, 'CrossFire', 'https://i.ibb.co/6RVsnBD/Cross-Fire-Zero.jpg'),
	(29, 'Among Us', 'https://zapgrupos.com/grupos/thumb/Grupo_zapgrupos_2509200600c6edef3925cd42e4bc4bda4057d0a10e.jpeg'),
	(30, 'Warcraft', 'https://a-static.mlcdn.com.br/618x463/world-of-warcraft-battle-for-azeroth-expansao-para-pc-blizzard/magazinefuturistic/047875882898/ea3b0fcf10a20aa64566d18d33ec6915.jpg'),
	(31, 'Tom Clancy\'s Rainbow Six: Siege', 'https://s2.gaming-cdn.com/images/products/406/271x377/jogo-uplay-tom-clancys-rainbow-six-siege-cover.jpg'),
	(32, 'Subway Surfers', 'https://pbs.twimg.com/profile_images/378800000809299597/a09590dfdec7bcab3110d2693e013a5f.jpeg'),
	(33, 'Clash Royale', 'https://www.zapgrupos.com/grupos/thumb/imgZapGrupos_1801181133090.jpg'),
	(34, 'Clash of Clans', 'https://pbs.twimg.com/profile_images/735449582885163008/GiyCMojZ_400x400.jpg'),
	(35, 'Pokémon Go', 'https://pokemongolive.com/img/posts/gobattleleague-season1.jpg'),
	(36, 'cyberpunk 2077', 'https://www.techpowerup.com/review/cyberpunk-2077-benchmark-test-performance/images/small.png'),
	(37, 'Forza Horizon 4', 'https://upload.wikimedia.org/wikipedia/pt/5/5f/Capa_do_jogo_Forza_Horizon_4.jpg'),
	(7, 'Fortnite', 'https://www.gamereactor.pt/media/29/fortnitecodeshows_2482963.jpg');
/*!40000 ALTER TABLE `games` ENABLE KEYS */;

-- Copiando estrutura para tabela tccredesocial.mensagem
CREATE TABLE IF NOT EXISTS `mensagem` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` varchar(50) DEFAULT NULL,
  `id_para` varchar(50) DEFAULT NULL,
  `msg` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`msg_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=363 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela tccredesocial.mensagem: 3 rows
/*!40000 ALTER TABLE `mensagem` DISABLE KEYS */;
/*!40000 ALTER TABLE `mensagem` ENABLE KEYS */;

-- Copiando estrutura para tabela tccredesocial.posts
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `Img` varchar(255) DEFAULT NULL,
  `texto` text,
  `data_hora` varchar(255) DEFAULT NULL,
  `dia` varchar(255) DEFAULT NULL,
  `mes` varchar(255) DEFAULT NULL,
  `ano` varchar(255) DEFAULT NULL,
  `curtida` varchar(50) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela tccredesocial.posts: 4 rows
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` (`id`, `id_usuario`, `Img`, `texto`, `data_hora`, `dia`, `mes`, `ano`, `curtida`) VALUES
	(11, 128, 'Setupgaby.jpg', 'Meu Setup gamer', '23:30:33', '01', 'Dezembro', '21', '18'),
	(10, 127, 'postajoao.webp', 'Gosto muito de Jogar GTA', '23:28:04', '01', 'Dezembro', '21', '36'),
	(8, 125, 'jogo.jpg', 'Adoro Jogar Video Game', '23:18:59', '01', 'Dezembro', '21', '26');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;

-- Copiando estrutura para tabela tccredesocial.seguidores
CREATE TABLE IF NOT EXISTS `seguidores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usu` int(11) DEFAULT NULL,
  `id_seguidor` int(11) DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela tccredesocial.seguidores: 9 rows
/*!40000 ALTER TABLE `seguidores` DISABLE KEYS */;
/*!40000 ALTER TABLE `seguidores` ENABLE KEYS */;

-- Copiando estrutura para tabela tccredesocial.seguidores_comunidade
CREATE TABLE IF NOT EXISTS `seguidores_comunidade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_comunidade` int(11) DEFAULT NULL,
  `id_seguidor` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela tccredesocial.seguidores_comunidade: 0 rows
/*!40000 ALTER TABLE `seguidores_comunidade` DISABLE KEYS */;
/*!40000 ALTER TABLE `seguidores_comunidade` ENABLE KEYS */;

-- Copiando estrutura para tabela tccredesocial.usuario
CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `usuario` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) DEFAULT NULL,
  `nome_imagem` varchar(255) DEFAULT 'perfil.webp',
  `banner` varchar(255) DEFAULT NULL,
  `steam` varchar(255) DEFAULT NULL,
  `ubisoft` varchar(255) DEFAULT NULL,
  `epic` varchar(255) DEFAULT NULL,
  `bio` varchar(255) DEFAULT NULL,
  `primeiro_acesso` varchar(255) DEFAULT NULL,
  `game1` varchar(255) DEFAULT '1',
  `game2` varchar(255) DEFAULT '1',
  `game3` varchar(255) DEFAULT '1',
  `game4` varchar(255) DEFAULT '1',
  `game5` varchar(255) DEFAULT '1',
  `comunidade` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=131 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela tccredesocial.usuario: 4 rows
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` (`id`, `nome`, `usuario`, `email`, `senha`, `nome_imagem`, `banner`, `steam`, `ubisoft`, `epic`, `bio`, `primeiro_acesso`, `game1`, `game2`, `game3`, `game4`, `game5`, `comunidade`, `status`) VALUES
	(127, 'JoÃ£o Carlos', 'joao@gmail.com', 'joao@gmail.com', '202cb962ac59075b964b07152d234b70', 'perfiljoao.jpg', NULL, 'JoÃ£oCarlos', ' JoÃ£oCarlos', 'JoÃ£oCarlos', 'Adoro Jogar no computador', 'NAO', '28', '23', '23', '20', '27', 'NAO', NULL),
	(128, 'Gaby', 'Gaby@gmail.com', 'Gaby@gmail.com', '202cb962ac59075b964b07152d234b70', 'perfilgaby.jpg', NULL, 'Gaby99', ' Gaby99', 'Gaby99', 'Gosto de anime', 'NAO', '26', '11', '25', '33', '37', 'NAO', NULL),
	(125, 'Diego', 'diego@gmail.com', 'diego@gmail.com', '202cb962ac59075b964b07152d234b70', 'perfil.webp', NULL, 'Dgaspardi', ' Dgaspardi', 'Dgaspardi', 'Tudo o que vocÃª sonha um dia realiza', 'NAO', '23', '25', '28', '24', '29', 'NAO', NULL);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
