<?php
session_start();
include('../login/verifica_login.php');
include_once '../Conexao\conexao.php';

$idusu = $_SESSION['id']; 

$pasta = "../perfil/imagens";

$name = $_POST['nome'];

$sql = "select count(*) as total from usuario where nome = '$name'";
$result = mysqli_query($conexao, $sql);
$row = mysqli_fetch_assoc($result);

if ($row['total'] == 1) {
  $consulta = "SELECT * FROM usuario WHERE nome = '$name'";
  $con = $conexao->query($consulta) or die($mysqli->error);



  while ($info = $con->fetch_array()) {
    $img = $info['nome_imagem'];
    $steam = $info['steam'];
    $ubsoft = $info['ubisoft'];
    $epic = $info['epic'];
    $bio = $info['bio'];
    $nome = $info['nome'];
    $banner = $info['banner'];
    $id1 = $info['game1'];
    $id2 = $info['game2'];
    $id3 = $info['game3'];
    $id4 = $info['game4'];
    $id5 = $info['game5'];
    $id = $info['id'];
  };


  $consulta1 = "SELECT * FROM games WHERE id = $id1";
  $con1 = $conexao->query($consulta1) or die($mysqli->error);

  while ($info = $con1->fetch_array()) {
    $game1 = $info['game'];
    $img1 = $info['img'];
  }

  $consulta2 = "SELECT * FROM games WHERE id = $id2";
  $con2 = $conexao->query($consulta2) or die($mysqli->error);

  while ($info = $con2->fetch_array()) {
    $game2 = $info['game'];
    $img2 = $info['img'];
  }

  $consulta3 = "SELECT * FROM games WHERE id = $id3";
  $con3 = $conexao->query($consulta3) or die($mysqli->error);

  while ($info = $con3->fetch_array()) {
    $game3 = $info['game'];
    $img3 = $info['img'];
  }

  $consulta4 = "SELECT * FROM games WHERE id = $id4";
  $con4 = $conexao->query($consulta4) or die($mysqli->error);

  while ($info = $con4->fetch_array()) {
    $game4 = $info['game'];
    $img4 = $info['img'];
  }

  $consulta5 = "SELECT * FROM games WHERE id = $id5";
  $con5 = $conexao->query($consulta5) or die($mysqli->error);

  while ($info = $con5->fetch_array()) {
    $game5 = $info['game'];
    $img5 = $info['img'];
  }

?>

  <!DOCTYPE html>
  <html>

  <head>
    <title>Games Stars</title>

    <!-- Required meta tags -->

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../perfil/cs.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="../js/jquery.js"></script>
    <script src="../js/seguir.js"></script>
  </head>

  <body>

  <div class="container">
    <div class="navigation">
      <div class="logo">
        <a class="no-underline" href="../login/painel.php">
         Gamer Stars
        </a>
      </div>
      <div class="navigation-search-container">
        <i class="fa fa-search"></i>
        <form action="../pesquisa/perfilpesquisa.php" method="post">
          <input class="search-field" name="nome" type="text" placeholder="Search">
        </form>
        <div class="search-container">
          <div class="search-container-box">
            <div class="search-results">

            </div>
          </div>
        </div>
      </div>
      <div class="icones">

      <a href="../chat/user.php"> <img src="../icons/mensagem.png" title="Mensagens" class="img"></a>

      <a href="#"> <img src="../icons/comunidade.png" title="Comunidades"class="img"></a>

      <a href="../configurracao/configurracao.php"> <img src="../icons/config.png" title="Configurações"class="img"></a>

      <a href="../login/logout.php"> <img src="../icons/sair.png" title="Sair"class="img"></a>
      </div>

    </div>
    </i>
    </a>

  </div>
    </div>


    <!-- corpo perfil-->

    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div id="content" class="content content-full-width">
            <div class="profile">
              <div class="profile-header">
                <div class="Profile-principal">
                  <div class="profile-header-content">
                    <div class="info">
                      <div class="profile-header-img">
                        <?php echo "<img src= $pasta/$id/$img />"; ?>
                      </div>
                    </div>
                    <div class="fundo">
                    </div>
                    <div class="profile-header-info">
                      <h4 class="m-t-10 m-b-5"><?php echo $nome; ?></h4>
                      <p class="m-b-10"><?php echo "$bio"; ?></p>
                    </div>
                    <div class="profile-games-titulo">
                      <div class="nicks"><img class="icons-profile" src="../icons/steam.png"> <?php echo "$steam"; ?> </div>
                      <br>
                      <div class="nicks"><img class="icons-profile" src="../icons/ubsoft.png"> <?php echo "$ubsoft"; ?> </div>
                      <br>
                      <div class="nicks"><img class="icons-profile" src="../icons/epic.png"> <?php echo "$epic"; ?> </div>
                    </div>
                    <ul class="profile-header-tab nav nav-tabs">
                        <?php
                        $sql2 = "select count(*) as total from seguidores where id_seguidor = '$id'";
                        $result2 = mysqli_query($conexao, $sql2);
                        $row2 = mysqli_fetch_assoc($result2);

                        if ($row2['total'] == 1) {
                        ?>
                          <li class="nav-item-seguir"><a href="#"class="nav-link" id="deixar"  usuario2deixar="<?php echo "$idusu" ?>" usuariodeixar="<?php echo "$id" ?>">DEIXAR DE SEGUIR </a></li>
                        <?php
                        } else {
                        ?>
                          <li class="nav-item-seguir"><a href="#"class="nav-link" id="seguir" usuarioSeguir="<?php echo "$id" ?>" usuarioSeguir2="<?php echo "$idusu" ?>">SEGUIR</a></li>
                        <?php
                        }
                        ?>
                      </ul>
                  </div>
                </div>
              </div>
              <div class="gameslegenda"></div>
              <div>
                <center class="gameslegenda3">
                  <h4>GAMES JOGADOS</h4>
                </center>
              </div>
              <div class="games">
                <div class="profile-games">
                  <img src="<?php echo "$img1" ?>" width="250px">
                  <div class="info-profile">
                    <h1><?php echo "$game1"; ?></h1>
                  </div>
                </div>
                <div class="profile-games">
                  <img src="<?php echo $img2; ?>" width="250px">
                  <div class="info-profile">
                    <h1><?php echo "$game2"; ?></h1>
                  </div>
                </div>
                <div class="profile-games">
                  <img src="<?php echo "$img3" ?>" width="250px">
                  <div class="info-profile">
                    <h1><?php echo "$game3" ?></h1>
                  </div>
                </div>
                <div class="profile-games">
                  <img src="<?php echo "$img4" ?>" width="250px">
                  <div class="info-profile">
                    <h1><?php echo "$game4" ?></h1>
                  </div>
                </div>
                <div class="profile-games">
                  <img src="<?php echo "$img5"; ?>" width="250px">
                  <div class="info-profile">
                    <h1><?php echo "$game5" ?></h1>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

  </body>

  </html>
<?php
} else {

  include_once '../view/navbar.php';
?>
  <html>

  <body>

    <div class="usernaoencon">
      <div class="usernaoencontrado">
        <p>Usuário não encontrado</p>
      </div>
      <center><a class="txt1" href="/redesocial1.0/login/painel.php">
          Voltar
        </a></center>
    </div>
    </div>
  </body>

  </html>
<?php } ?>





<link rel="stylesheet" type="text/css" href="../perfil/cs.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">