<ul class="profile-header-tab nav nav-tabs">
                        <li class="nav-item"><a href="#profile-photos" class="nav-link">FOTOS</a></li>
                        <li class="nav-item"><a href="#profile-friends" class="nav-link">AMIGOS</a></li>
                        <?php
                        $sql2 = "select count(*) as total from seguidores where id_seguidor = '$id'";
                        $result2 = mysqli_query($conexao, $sql2);
                        $row2 = mysqli_fetch_assoc($result2);

                        if ($row2['total'] == 1) {
                        ?>
                          <li class="nav-item-seguir"><a href="#" class="nav-link" deixar="deixar"  usuario2deixar="<?php echo "$idusu" ?>">DEIXAR DE SEGUIR </a></li>
                        <?php
                        } else {
                        ?>
                          <li class="nav-item-seguir"><a href="#" class="nav-link" seguir="seguir" usuarioSeguir="<?php echo "$id" ?>" usuarioSeguir2="<?php echo "$idusu" ?>">SEGUIR</a></li>
                        <?php
                        }
                        ?>
                      </ul>