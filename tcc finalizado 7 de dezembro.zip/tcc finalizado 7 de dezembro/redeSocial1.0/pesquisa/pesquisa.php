
<?php 

 $nome = $_POST['nome'];

session_start();
include('../login/verifica_login.php');
include_once '../Conexao\conexao.php';


 $consulta = "SELECT * FROM usuario WHERE nome = '$nome'; ";
 $con = $conexao->query($consulta) or die ($mysqli->error);
