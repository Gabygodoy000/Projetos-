<?php

    include_once '../conexao/comentarDAO.php';

    $post = $_POST['post'];

    $comDao = new ComentarDAO();
    $res = $comDao->listar($post);

    echo json_encode($res);


?>