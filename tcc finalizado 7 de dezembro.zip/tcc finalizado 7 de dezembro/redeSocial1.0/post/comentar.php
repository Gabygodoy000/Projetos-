<?php
    
    include_once '../conexao/comentarDAO.php';

    $post = $_POST['post'];
    $usuario = $_POST['usuario'];
    $comentario = $_POST['comentario'];
    $nome = $_POST['nome'];
    $img = $_POST['img'];

     $comentDao = new comentarDAO  ();
    
     $res = $comentDao->inserir($usuario,$comentario,$post);

     if ($res == false) {
        echo json_encode("falha ao tentar comentar!");
     } else{

?>
<img src="<?php echo "$img";?>" alt="" width='50px'>
<p><?php echo "$nome";?>: <?php echo "$comentario";?></p>
 <?php
             }
 ?>  