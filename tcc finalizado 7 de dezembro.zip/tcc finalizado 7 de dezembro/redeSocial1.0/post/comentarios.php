<?php
include_once '../conexao/conexao.php';
$post = $_POST['post'];

echo json_encode($post);

if ($total <= 0) {
	echo "<div class='alert alert-danger'>Nenhuma publicação encontrada!</div>";
} else {
	while ($dados = $get->fetch_array()) {
		$idPost = $dados['id'];
		$idPostador = $dados['id_usuario'];
		$query = $conexao->prepare("SELECT * FROM usuario WHERE id = ?");
		$query->bind_param("s", $idPostador);
		$query->execute();
		$dadosU = $query->get_result()->fetch_assoc();
		$img2 = $dadosU['nome_imagem'];
		$img = $dados['Img'];
		$diretorio = "../post/imagens/$idPostador/$img";
		$diretorio2 = "../perfil/imagens/$idPostador/$img2";
		$curtidas= $dados['curtida'];

?>

		<link rel="stylesheet" type="text/css" href="../pefil/cs.css">

		<div class="post-content">
			<div>
				<div class="imgfeed">
					<img src="<?php echo "$diretorio2"; ?>" alt="">
				</div>
				<div class="nomefeed">
					<h4><?php echo $dadosU['nome']; ?></h4>
					<h6><?php echo $dados['texto'] ?></h6>
				</div>
			</div>
			<div class="media">
				<img src="<?php echo "$diretorio"; ?>" alt="">
			</div>
			<div class="coment">
			<span class="tw-heart-box">
				<input type="checkbox" id="btn-curtir" usuario="<?php echo $idusu ?>"  curtida="<?php echo $curtidas ?>" post="<?php echo $idPost ?>">
				<span class="tw-heart"></span>
			   <div id ="numcurt">
				<?php echo "$curtidas"; ?>
				</div>
			</span>
			<a href="#"  comentar="comentario" usuario="<?php echo $idusu ?>" post="<?php echo $idPost ?>" img="<?php echo $diretorio2 ?>" nome="<?php echo $nome2 ?>"><img src="../icons/comentario.png"></a>
			</div>
		</div>

<?php }
} ?>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header bg-dark text-white">
				<h5 class="modal-title" id="exampleModalLabel">Deixe o seu cometário</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">&times;</button>
			</div>
			<div class="modal-body bg-dark text-white">
				<div id="lista-comentario">
				</div>
				<form id="comentar-form">
					<input class="form-control" type="text" id="comentar onfocus="if(this.value=='A new value') this.value='';"">
				</form>
			</div>
			<div class="modal-footer bg-dark text-white">
				<button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
				<button type="button" id="comentComfirm" class="btn btn-success">Comentar</button>
			</div>
		</div>
	</div>
</div>
<script src="../js/jquery.js"></script>
