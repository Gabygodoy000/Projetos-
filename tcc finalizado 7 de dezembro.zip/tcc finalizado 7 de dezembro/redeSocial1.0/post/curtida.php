<?php
    
    include_once '../conexao/conexao.php';
    include_once '../conexao/curtidaDAO.php';

    $post = $_POST['post'];
    $usuario = $_POST['usuario'];

    $curtDao = new CurtidaDAO();
    $usuInfo = $curtDao->verificaCurtida($post, $usuario);
    if ($usuInfo){
        
        $curtDao->delete($usuario, $post);
        
        $sql2 = $conexao->prepare("SELECT * FROM posts where id = $post");
        $sql2->execute();
        $get2 = $sql2->get_result();
        while ($dados2 = $get2->fetch_array()) {
            $nome = $dados2['curtida'];
        }
        echo ($nome);

    } else {
        $curtDao->inserir($post, $usuario);

        $sql2 = $conexao->prepare("SELECT * FROM posts where id = $post");
        $sql2->execute();
        $get2 = $sql2->get_result();
        while ($dados2 = $get2->fetch_array()) {
            $nome = $dados2['curtida'];
        }
        echo ($nome);

 }?>