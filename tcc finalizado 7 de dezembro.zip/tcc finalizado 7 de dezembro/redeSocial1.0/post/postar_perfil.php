<?php 
session_start();
include("../conexao/conexao.php");

$id = $_SESSION['id'];

$dia = date("d");
$mes = date ("m");
$ano = date("y");

$meses=array("Janeiro","Feveriro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro");

$mes2 = $meses[$mes-1];
$hora = date('H:i:s');


//Verificar se o usuário clicou no botão, clicou no botão acessa o IF e tenta cadastrar, caso contrario acessa o ELSE
$SendCadImg = filter_input(INPUT_POST, 'SendCadImg', FILTER_SANITIZE_STRING);

if ($SendCadImg) {
    //Receber os dados do formulário
$desc = mysqli_real_escape_string($conexao, trim($_POST['desc']));
$banner = mysqli_real_escape_string($conexao, trim($_FILES['banner']['name']));

   //var_dump($_FILES['banner']);
    //Inserir no BD
            
    $sql = "INSERT INTO posts (id_usuario, img, texto, data_hora, dia, mes, ano) VALUES ('$id', '$banner','$desc', '$hora','$dia', '$mes2','$ano' ); ";
    $conexao->query($sql);


   // echo " $id_usuario/ $desc/ $banner/ $dia/$mes/$ano/$hora";
    //echo "é nois";
 
      //Verificar se os dados foram inseridos com sucesso
     if ($conexao->close()) {

        //Recuperar último ID inserido no banco de dados
      $ultimo_id = $id;
        //Diretório onde o arquivo vai ser salvo
        $diretorio = '../post/imagens/' . $ultimo_id.'/';

        //Criar a pasta de foto 
        mkdir($diretorio, 0755);
        move_uploaded_file($_FILES['banner']['tmp_name'], $diretorio.$banner);
     
        
        if(move_uploaded_file($_FILES['imagem']['tmp_name'], $diretorio.$nome_imagem)){
            $_SESSION['msg'] = "<p style='color:green;'>Dados salvo com sucesso e upload da imagem realizado com sucesso</p>";
            header("Location: editPerfil.php");
        }else{
            $_SESSION['msg'] = "<p><span style='color:green;'>Dados salvo com sucesso. </span><span style='color:red;'>Erro ao realizar o upload da imagem</span></p>";
            header("Location: ../login/painel.php");
        }        
    } else {
        $_SESSION['msg'] = "<p style='color:red;'>Erro ao salvar os dados</p>";
        header("Location: perfl.php");
    }
} else {
    $_SESSION['msg'] = "<p style='color:red;'>Erro ao salvar os dados</p>";
    header("Location: Perfil.php");
}
