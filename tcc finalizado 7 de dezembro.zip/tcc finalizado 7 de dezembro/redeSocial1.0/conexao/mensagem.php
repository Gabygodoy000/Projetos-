<?php
date_default_timezone_set('America/São paulo');
$globalData = date("d/m/y");
$globalHora = date("H:I");
$showNome = false;

if(isset($_SESSION['usuario']) && $_SESSION['usuario'] =! null){
	$nomeAtual = $_SESSION['usuario'];
}

?>