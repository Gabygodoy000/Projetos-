<?php

    include_once 'conexao.php';

    class comentarDAO{

        public function inserir($usuario,$comentario,$post){
            $pdo = Conexao::getInstance();
            $sql = $pdo->prepare("INSERT INTO comentarios VALUES (default, ?, ?, ?)");
            $sql->execute(array($usuario,$comentario,$post));
            if ($sql->rowCount() == 1){
                return true;
            } else {
                return false;
            }

        }

        public function listar($post){
            $pdo = Conexao::getInstance();
            $sql = $pdo->prepare("SELECT * FROM comentarios INNER JOIN usuario ON comentarios.id_usuario = usuario.id WHERE id_post = $post");
            $sql->execute();
            $conInfo = $sql->fetchAll(PDO::FETCH_ASSOC);
            return $conInfo;

        }
    }