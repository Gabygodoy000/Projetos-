<?php

    include_once 'conexao.php';

    class curtidaDAO{
        public function verificaCurtida($post, $usuario){
            try{
                $pdo = Conexao::getInstance();
                $sql = $pdo->prepare("SELECT * FROM curtir WHERE id_post =? AND id_usuario =?;");
                $sql->execute(array($post, $usuario));
                $usuInfo = $sql->fetchAll(PDO::FETCH_ASSOC);
                return $usuInfo;
            }catch (PDOException $e){
                print $e->getMessage();
            }
        }

        public function inserir($post, $usuario){
            $pdo = Conexao::getInstance();
            $sql = $pdo->prepare("INSERT INTO curtir VALUES (default, ?,?);UPDATE posts SET curtida=curtida+1 WHERE id=? ;");
            $sql->execute(array($post, $usuario, $post ));

        }
        public function delete($usuario, $post){
            $pdo =  Conexao::getInstance();
            $sql = $pdo->prepare("DELETE FROM curtir WHERE id_usuario = ?;UPDATE posts SET curtida=curtida-1 WHERE id=? ;");
            $sql->execute(array($usuario, $post ));
        }
    }