<?php

    include_once 'conexao.php';

    class mensagemDAO{

        public function inserir($usuario,$mensagem,$para,$hora){
            $pdo = Conexao::getInstance();
            $sql = $pdo->prepare("INSERT INTO mensagem VALUES (default, ?, ?, ?,?)");
            $sql->execute(array($usuario,$mensagem,$para,$hora));
            if ($sql->rowCount() == 1){
                return true;
            } else {
                return false;
            }

        }

        public function listar($para){
            $pdo = Conexao::getInstance();
            $sql = $pdo->prepare("SELECT * FROM mensagem WHERE id_para = $para");
            $sql->execute();
            $conInfo = $sql->fetchAll(PDO::FETCH_ASSOC);
            return $conInfo;

        }

    }