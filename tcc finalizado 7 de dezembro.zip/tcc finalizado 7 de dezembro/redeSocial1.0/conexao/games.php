<?php
	include_once '..\conexao\conexao.php';

    	class UsuarioDAO{

		public function Alterar(Usuario $usu){
			try{
				if ((!empty($usu->getId()))) {
					$altera = "UPDATE games_usuario SET id_game 'igor' WHERE id = :id";
							   
					$alt = Conexao::getInstance()->prepare($altera);
					
					$alt->bindValue(":id", $usu->getId());

					return $alt->execute();
				} else {
					return false;
				}
				
			}catch(PDOException $e){
				print $e->getMessage();
			}
		}
	}	
?>