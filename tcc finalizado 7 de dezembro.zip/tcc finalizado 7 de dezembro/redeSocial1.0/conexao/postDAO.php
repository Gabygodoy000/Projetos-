<?php
    include_once 'conexao.php';

    class postDAO{
        public function Listar(){
            try{
                
            }catch(PDOException $e){
                print $e->getMessage();
            }
        }
    }
?>