<?php

    include_once 'conexao.php';

    class segDAO{

        public function listar($usuario2,$usuario){
            $pdo = Conexao::getInstance();
            $sql1 = $pdo->prepare("SELECT * FROM seguidores WHERE id_usu=? AND id_seguidor=? AND STATUS='0'");
            $sql1->execute(array($usuario2 ,$usuario));
            $conInfo = $sql1->fetchAll(PDO::FETCH_ASSOC);
            return $conInfo;
        }

        public function inserir($usuario2,$usuario ){
            $pdo = Conexao::getInstance();
            $sql2 = $pdo->prepare("INSERT INTO seguidores VALUES (default,? ,?,'0')");
            $sql2->execute(array($usuario2 ,$usuario));
        }
        public function update($usuario2,$usuario){
            $pdo = Conexao::getInstance();
            $sql =$pdo->prepare("UPDATE seguidores SET STATUS='1' WHERE id_usu=? AND id_seguidor=?");
            $sql->execute(array($usuario2,$usuario));

        }
        public function delete($usuario2){
            $pdo =  Conexao::getInstance();
            $sql3 = $pdo->prepare("DELETE FROM seguidores WHERE id_usu = ?;");
            $sql3->execute(array($usuario2));
        }
    }