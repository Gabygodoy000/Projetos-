<?php
require_once('src/PHPMailer.php');
require_once('src/SMTP.php'); 
require_once('src/Exception.php'); 

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

try{
	$mail->SMTPdebug = SMTP::DEBUG_SERVER;
	$mail->isSMTP();
	$mail->host = 'SMTP.gmail.com';
	$mail->SMTPAutch = true;
	$mail->Username = 'Iginvestimento2019@gmail.com';
	$mail->Password = '997352753';
	$mail->Port = 587;

	$mail->SetFrom('Iginvestimento2019@gmail.com');
	$mail->addAddress('igorteodoro2409@gmail.com');

	$mail->isHTML(true);
	$mail->Subject = 'teste de email via gmail';
	$mail->body = 'chegou <strong>Igão</strong>';
    $mail->altBody = ' igao';

    if ($mail->send()) {
    	echo "Email invalido";
    }
    else{
    	echo 'email n enviado';
    }
} catch (Exception $e) {
	echo "Erro ao enviar mensagem: {$mail->ErrorInfo}";
}

 
?>