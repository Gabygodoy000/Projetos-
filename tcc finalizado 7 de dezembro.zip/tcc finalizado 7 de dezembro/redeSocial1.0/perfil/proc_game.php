
<?php 
 include_once '../conexao/conexao.php';


    for ($i = 1 ; ; $i++) {

    $result_img = "INSERT INTO games_usuario (id_usuario, id_game) VALUES ('1', '1'); ";
    $insert_msg = $conn->prepare($result_img);
    $insert_msg-> execute(); 
    	if ($i >= 5) {
        break;
}
}

 ?>