<?php 
session_start();
include_once '../conexao/conexao.php';

//Verificar se o usuário clicou no botão, clicou no botão acessa o IF e tenta cadastrar, caso contrario acessa o ELSE
$SendCadImg = filter_input(INPUT_POST, 'SendCadImg', FILTER_SANITIZE_STRING);

if ($SendCadImg) {
    //Receber os dados do formulário
    $nome = $_POST['nome'];
    $desc = $_POST['desc'];
    $steam = $_POST['steam'];
    $ubsoft = $_POST['ubsoft'];
    $epic = $_POST['epic'];
    $nome_imagem = $_FILES['imagem']['name'];

    $id = $_SESSION['id'];
    $game1 = $_POST['game1'];
	$game2 = $_POST['game2'];
	$game3 = $_POST['game3'];
	$game4 = $_POST['game4'];
	$game5 = $_POST['game5'];
    
    

 
    //Inserir no BD
    $result_img = "UPDATE usuario SET nome_imagem = (:imagem), banner = (:banner), nome = (:nome), steam = (:steam), ubisoft= (:ubsoft), epic = (:epic), bio = (:descr), game1 = (:game1), game2 = (:game2), game3 = (:game3), game4 = (:game4), game5 = (:game5) WHERE id = $id ";
    $insert_msg = $conn->prepare($result_img);
    $insert_msg->bindParam(':imagem', $nome_imagem);
    $insert_msg->bindParam(':banner', $banner);
    $insert_msg->bindParam(":nome", $nome);
    $insert_msg->bindParam(':descr', $desc);
    $insert_msg->bindParam(":steam", $steam);
    $insert_msg->bindParam(':ubsoft', $ubsoft);
    $insert_msg->bindParam(":epic", $epic);
    $insert_msg->bindParam(":steam", $steam);
    $insert_msg->bindParam(':game1', $game1);
    $insert_msg->bindParam(':game2', $game2);
    $insert_msg->bindParam(':game3', $game3);
    $insert_msg->bindParam(':game4', $game4);
    $insert_msg->bindParam(':game5', $game5);
    

   

    echo " $id, /$nome/ $nome_imagem/ $desc/$steam/$ubsoft/$epic/$banner";

    //Verificar se os dados foram inseridos com sucesso
    if ($insert_msg->execute()) {
        //Recuperar último ID inserido no banco de dados
        $ultimo_id = $id;
        //Diretório onde o arquivo vai ser salvo
        $diretorio = 'imagens/' . $ultimo_id.'/';

        //Criar a pasta de foto 
        mkdir($diretorio, 0755);
        move_uploaded_file($_FILES['banner']['tmp_name'], $diretorio.$banner);
     
        
        if(move_uploaded_file($_FILES['imagem']['tmp_name'], $diretorio.$nome_imagem)){
            $_SESSION['msg'] = "<p style='color:green;'>Dados salvo com sucesso e upload da imagem realizado com sucesso</p>";
            header("Location: Perfil.php");
        }else{
            $_SESSION['msg'] = "<p><span style='color:green;'>Dados salvo com sucesso. </span><span style='color:red;'>Erro ao realizar o upload da imagem</span></p>";
            header("Location: Perfil.php");
        }        
    } else {
        $_SESSION['msg'] = "<p style='color:red;'>Erro ao salvar os dados</p>";
        header("Location: perfil.php");
    }
} else {
    $_SESSION['msg'] = "<p style='color:red;'>Erro ao salvar os dados</p>";
    header("Location: Perfil.php");
}
