<?php 
session_start();
include('../login/verifica_login.php');
include_once '../Conexao\conexao.php';


$id = $_SESSION['id'];


$consulta = "SELECT * FROM usuario WHERE id = $id";
$con = $conexao->query($consulta) or die ($mysqli->error);

$consulta2 = "SELECT * FROM games";
$con2 = $conexao->query($consulta2) or die ($mysqli->error);

$consulta3 = "SELECT * FROM games";
$con3 = $conexao->query($consulta3) or die ($mysqli->error);

$consulta4 = "SELECT * FROM games";
$con4 = $conexao->query($consulta4) or die ($mysqli->error);

$consulta5 = "SELECT * FROM games";
$con5 = $conexao->query($consulta5) or die ($mysqli->error);

$consulta6 = "SELECT * FROM games";
$con6 = $conexao->query($consulta6) or die ($mysqli->error);


?>
<!DOCTYPE html>
<html>
<head>
  <title>Games Stars</title>
<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="cs.css">


  </head>
  <body>
<?php include_once'../view/navbar.php'; ?>

<!-- body -->

<div class="container">
   <div class="row">
      <div class="col-md-12">
         <div id="content" class="content content-full-width">
            <!-- begin profile -->
            <div class="profile">
               <div class="profile-header">
               	<div class="form-group">
                  <!-- BEGIN profile-header-cover -->
                  <!-- END profile-header-cover -->
                  <!-- BEGIN profile-header-content -->
                
                     <!-- BEGIN profile-header-img -->
                    
                     
                          
                     <!-- END profile-header-img -->
                     <!-- BEGIN profile-header-info -->

                  
                     <!-- END profile-header-info -->
                 
              <form method="POST" action="proc_cad_img.php" enctype="multipart/form-data">
  
         
          
                 </form>
            <!-- editar jogos -->
             <div align="center" class="bioEdit">
             	<form method="POST" action="games_editar.php" enctype="multipart/form-data">
               <h1>Atualizar lista de jogos</h1>
               		<br>
               		<label for="exampleFormControlSelect1"><p>Selecione o game 1</p></label>
    				<select name="game1" class="form-control" id="exampleFormControlSelect1">
    					<?php while($info = $con2->fetch_array()) { ?>
						<option value="<?php echo $info["id"]; ?>"><?php echo $info["game"]; ?></option>
                    	<?php } ?>
    				</select>
    				<br>
    				<label for="exampleFormControlSelect1"><p>Selecione o game 2</p></label>
    				<select class="form-control" id="exampleFormControlSelect1">
      					<?php while($info = $con3->fetch_array()) { ?>
						<option><?php echo $info["game"]; ?></option>
                    	<?php } ?>
    				</select>
    				<br>
    				<label for="exampleFormControlSelect1"><p>Selecione o game 3</p></label>
    				<select class="form-control" id="exampleFormControlSelect1">
      					<?php while($info = $con4->fetch_array()) { ?>
						<option><?php echo $info["game"]; ?></option>
                    	<?php } ?>
    				</select>
    				<br>
    				<label for="exampleFormControlSelect1"><p>Selecione o game 4</p></label>
    				<select class="form-control" id="exampleFormControlSelect1">
      					<?php while($info = $con5->fetch_array()) { ?>
						<option><?php echo $info["game"]; ?></option>
                    	<?php } ?>
    				</select>
    				<br>
    				<label for="exampleFormControlSelect1"><p>Selecione o game 5</p></label>
    				<select class="form-control" id="exampleFormControlSelect1">
      					<?php while($info = $con6->fetch_array()) { ?>
						<option><?php echo $info["game"]; ?></option>
                    	<?php } ?>
    				</select>
    				<br>	
    				 <input type="submit" name="enviar">
    				</form>
    			</div>

  				</div>
            </div>
            <!-- end profile -->
            <!-- begin profile-content -->
          
                  <!-- end #profile-post tab -->
               </div>
               <!-- end tab-content -->
            </div>
            <!-- end profile-content -->
         </div>
      </div>
 
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
