<?php
session_start();
    include_once '..\conexao\conexao.php';

    $id = $_SESSION ['id'];
	$game1 = $_POST['game1'];
	$game2 = $_POST['game2'];
	$game3 = $_POST['game3'];
	$game4 = $_POST['game4'];
	$game5 = $_POST['game5'];

	
    $result = "UPDATE usuario SET game1 = (:game1), game2 = (:game2), game3 = (:game3), game4 = (:game4), game5 = (:game5) WHERE id= $id;";
    $insert_msg = $conn->prepare($result);

    $insert_msg->bindParam(':game1', $game1);
    $insert_msg->bindParam(':game2', $game2);
    $insert_msg->bindParam(':game3', $game3);
    $insert_msg->bindParam(':game4', $game4);
    $insert_msg->bindParam(':game5', $game5);
    $insert_msg->execute();

    header("Location: perfil.php");


?>