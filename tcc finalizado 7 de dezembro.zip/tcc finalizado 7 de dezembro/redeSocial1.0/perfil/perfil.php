<?php
session_start();
include('../login/verifica_login.php');
include_once '../Conexao\conexao.php';

$pasta = "../perfil/imagens";

$id = $_SESSION['id'];

$consulta = "SELECT * FROM usuario WHERE id = $id";
$con = $conexao->query($consulta) or die($mysqli->error);

while ($info = $con->fetch_array()) {
  $img = $info['nome_imagem'];
  $steam = $info['steam'];
  $ubsoft = $info['ubisoft'];
  $epic = $info['epic'];
  $bio = $info['bio'];
  $nome = $info['nome'];
  $banner = $info['banner'];
  $id1 = $info['game1'];
  $id2 = $info['game2'];
  $id3 = $info['game3'];
  $id4 = $info['game4'];
  $id5 = $info['game5'];
};


$consulta1 = "SELECT * FROM games WHERE id = $id1";
$con1 = $conexao->query($consulta1) or die($mysqli->error);

while ($info = $con1->fetch_array()) {
  $game1 = $info['game'];
  $img1 = $info['img'];
}

$consulta2 = "SELECT * FROM games WHERE id = $id2";
$con2 = $conexao->query($consulta2) or die($mysqli->error);

while ($info = $con2->fetch_array()) {
  $game2 = $info['game'];
  $img2 = $info['img'];
}

$consulta3 = "SELECT * FROM games WHERE id = $id3";
$con3 = $conexao->query($consulta3) or die($mysqli->error);

while ($info = $con3->fetch_array()) {
  $game3 = $info['game'];
  $img3 = $info['img'];
}

$consulta4 = "SELECT * FROM games WHERE id = $id4";
$con4 = $conexao->query($consulta4) or die($mysqli->error);

while ($info = $con4->fetch_array()) {
  $game4 = $info['game'];
  $img4 = $info['img'];
}

$consulta5 = "SELECT * FROM games WHERE id = $id5";
$con5 = $conexao->query($consulta5) or die($mysqli->error);

while ($info = $con5->fetch_array()) {
  $game5 = $info['game'];
  $img5 = $info['img'];
}
$diretorioPerfil = "../perfil/imagens/$id/$img";
?>

<!DOCTYPE html>
<html>

<head>
  <title>Games Stars</title>

  <!-- Required meta tags -->

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="cs.css">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" media="screen" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
</head>

<body>

  <div class="container">
    <div class="navigation">
      <div class="logo">
        <a class="no-underline" href="../login/painel.php">
         Gamer Stars
        </a>
      </div>
      <div class="navigation-search-container">
        <i class="fa fa-search"></i>
        <form action="../pesquisa/perfilpesquisa.php" method="post">
          <input class="search-field" name="nome" type="text" placeholder="Search">
        </form>
        <div class="search-container">
          <div class="search-container-box">
            <div class="search-results">

            </div>
          </div>
        </div>
      </div>
      <div class="icones">

      <a href="../chat/user.php"> <img src="../icons/mensagem.png" title="Mensagens" class="img"></a>

      <a href="../configurracao/configurracao.php"> <img src="../icons/config.png" title="Configurações"class="img"></a>

      <a href="../login/logout.php"> <img src="../icons/sair.png" title="Sair"class="img"></a>

        <a href="../perfil/perfil.php"> <img src="<?php echo $diretorioPerfil; ?>" alt="perfil" title="Perfil" class="fotofeed"></a>


      </div>

    </div>
    </i>
    </a>

  </div>
  </div>


  <!-- corpo perfil-->

  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div id="content" class="content content-full-width">
          <!-- begin profile -->
          <div class="profile">
            <div class="profile-header">
              <div class="Profile-principal">
                <!-- END profile-header-cover -->
                <!-- BEGIN profile-header-content -->
                <div class="profile-header-content">
                  <!-- BEGIN profile-header-img -->
                  <div class="info">
                    <div class="profile-header-img">
                    <a href="../perfil/editperfil.php" title="Editar Perfil"><label class="avatar" for="btn"></a>
                    <?php echo "<img src= $pasta/$id/$img />" ; ?>
                    </label> 
                </div>
                  </div>
                  <!-- END profile-header-img -->
                  <!-- BEGIN profile-header-info -->
                  <div class="profile-header-info">
                    <h4 class="m-t-10 m-b-5"><?php echo $nome; ?></h4>
                    <p class="m-b-10"><?php echo "$bio"; ?></p>
                  </div>

                  <div class="profile-games-titulo">
                    <div class="nicks"><img class="icons-profile" src="../icons/steam.png" title="Steam"> <?php echo "$steam"; ?> </div>
                    <br>
                    <div class="nicks"><img class="icons-profile" src="../icons/epic.png" title="Epic Games"> <?php echo "$epic"; ?> </div>
                    <br>
                    <div class="nicks"><img class="icons-profile" src="../icons/ubsoft.png" title="Ubsoft"> <?php echo "$ubsoft"; ?> </div>
                  </div>
                </div>
                <!-- END profile-header-info -->
              </div>
            </div>
            <div>
              <div class="gameslegenda3">
                <center>
                  <hr class="hr2">
                  <h4>GAMES JOGADOS</h4>
                  <hr class="hr">
                </center>
              </div>
            </div>

            <div class="games">

              <div class="profile-games">
                <img src="<?php echo "$img1" ?>" width="250px">
                <div class="info-profile">
                  <h1><?php echo "$game1"; ?></h1>
                </div>
              </div>
              <div class="profile-games">
                <img src="<?php echo $img2; ?>" width="250px">
                <div class="info-profile">
                  <h1><?php echo "$game2"; ?></h1>
                </div>
              </div>
              <div class="profile-games">
                <img src="<?php echo "$img3" ?>" width="250px">
                <div class="info-profile">
                  <h1><?php echo "$game3" ?></h1>
                </div>
              </div>
              <div class="profile-games">
                <img src="<?php echo "$img4" ?>" width="250px">
                <div class="info-profile">
                  <h1><?php echo "$game4" ?></h1>
                </div>
              </div>
              <div class="profile-games">
                <img src="<?php echo "$img5"; ?>" width="250px">
                <div class="info-profile">
                  <h1><?php echo "$game5" ?></h1>
                </div>
              </div>

            </div>

          </div>
          <!-- end profile -->
          <!-- begin profile-content -->

          <!-- end #profile-post tab -->
        </div>
        <!-- end tab-content -->
      </div>
      <!-- end profile-content -->
    </div>
  </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>