<?php
 
 session_start();
include("../conexao/conexao.php");

    $id = $_SESSION ['id'];
	$usuario = $_POST['usuario'];
	$email= $_POST['email'];
	$senha = md5($_POST['senha']);

	
    $result = "UPDATE usuario SET usuario = (:usuario), email = (:email), senha = (:senha) WHERE id= $id;";
    $insert_msg = $conn->prepare($result);

    $insert_msg->bindParam(':usuario', $usuario);
    $insert_msg->bindParam(':email', $email);
    $insert_msg->bindParam(':senha', $senha);
    $insert_msg->execute();

    header("Location: ../perfil/perfil.php");