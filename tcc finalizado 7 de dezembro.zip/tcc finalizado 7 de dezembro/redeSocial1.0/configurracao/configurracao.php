<?php
session_start();
include_once '../conexao/conexao.php';
$pasta = "../login/imagens";

$id = $_SESSION['id'];

$consulta = "SELECT * FROM usuario WHERE id = $id";
$con = $conexao->query($consulta) or die($mysqli->error);
while ($info = $con->fetch_array()) {

  $usuario = $info['usuario'];
  $email = $info['email'];

  //$consultaa = "SELECT * FROM games_usuario INNER JOIN usuario ON games_usuario.id_usuario = usuario.id INNER JOIN games ON games_usuario.id_game = games.id WHERE id_usuario =$id"; 
  //$cona = $conexao->query($consultaa) or die ($mysqli->error);

?>
  <!DOCTYPE html>
  <html>

  <head>
    <title>Games Stars</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../perfil/cs.css">


  </head>

  <body>

    <div class="container">
      <div class="navigation">
        <div class="logo">
          <a class="no-underline" href="../login/painel.php">
            Gamer Stars
          </a>
        </div>
        <div class="navigation-search-container">
          <i class="fa fa-search"></i>
          <form action="../pesquisa/perfilpesquisa.php" method="post">
            <input class="search-field" name="nome" type="text" placeholder="Search">
          </form>
          <div class="search-container">
            <div class="search-container-box">
              <div class="search-results">

              </div>
            </div>
          </div>
        </div>
        <div class="icones">

        <a href="../chat/user.php"> <img src="../icons/mensagem.png" title="Mensagens" class="img"></a>

        <a href="../configurracao/configurracao.php"> <img src="../icons/config.png" title="Configurações"class="img"></a>

        <a href="../login/logout.php"> <img src="../icons/sair.png" title="Sair"class="img"></a>


        </div>
      </div>
      </i>
      </a>

    </div>
    </div>


    <!-- body -->

    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div id="content" class="content content-full-width">
            <!-- begin profile -->
            <div class="profile">
              <div class="profile-header">
                <!-- BEGIN profile-header-cover -->
                <!-- END profile-header-cover -->
                <!-- BEGIN profile-header-content -->

                <!-- BEGIN profile-header-img -->



                <!-- END profile-header-img -->
                <!-- BEGIN profile-header-info -->


                <!-- END profile-header-info -->
                <center>
                  <form method="POST" action="config.php" enctype="multipart/form-data">
                    <div class="bioEdit">
                      <h1 class="m-b-10">Email Primario</h1>
                      <hr class="hr">
                      <p>Deseja trocar o seu E-mail de usuario?</p>
                      <center><input type="text" name="usuario" value="<?php echo "$usuario" ?>"></center>
                    </div>
                    <div class="bioEdit">
                      <h1 class="m-b-10">Email Secundario</h1>
                      <hr class="hr">
                      <p>Deseja trocar o seu E-mail secundario ou adicionar um E-mail secundario?</p>
                      <center><input type="text" name="email" value="<?php echo "$email" ?>"></center>
                    </div>
                    <div class="bioEdit">
                      <h1 class="m-b-10">Senha</h1>
                      <hr class="hr">
                      <p>Deseja trocar a sua senha de usuario?</p>
                      <center><input type="text" name="senha" placeholder="Digite uma senha nova"></center>
                    </div>
                    <center><input name="SendCadImg" class="btn btn-success" type="submit" name="enviar"></center>
              </div>

              <div align="center" class="bioEdit">
                <br>
                </center>
              </div>
            </div>
            <!-- end profile -->
            <!-- begin profile-content -->

            <!-- end #profile-post tab -->
          </div>
          <!-- end tab-content -->
        </div>
        <!-- end profile-content -->
      </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
<?php } ?>

  </html>