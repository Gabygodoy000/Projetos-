<script src="../js/jquery.js"></script>
<script src="../js/seguir.js"></script>
<?php
    include_once '../conexao/seguirDAO.php';
    include_once '../conexao/conexao.php';

    $usuario = $_POST['usuariodeixar'];
    $usuario2 = $_POST['usuariodeixar2'];

    $sql1 = $conn->prepare("SELECT * FROM seguidores WHERE id_usu=? AND id_seguidor=? AND STATUS='1'");
    $sql1->bindParam(1,$usuario);
    $sql1->bindParam(2,$usuario2);
    $sql1->execute();
     $fetch = $sql1->fetchAll();
     $usu = count($fetch);
     
    if($usu <=0){
        echo"erro";
    }else{
        $sql2 =$conn->prepare("UPDATE seguidores SET STATUS='0' WHERE id_usu=? AND id_seguidor=?");
        $sql2->bindParam(1,$usuario);
        $sql2->bindParam(2,$usuario2);
        $sql2->execute();
        if($sql2->rowCount() >= 1){
            echo"SEGUIR";

            $segDao = new segDAO  ();

            $res = $segDao->delete($usuario2);
        }else{
            echo"ERRO";
        }
    }
    
?>  