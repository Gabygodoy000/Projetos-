<?php 
session_start();
include("../conexao/conexao.php");

//Verificar se o usuário clicou no botão, clicou no botão acessa o IF e tenta cadastrar, caso contrario acessa o ELSE
$SendCadImg = filter_input(INPUT_POST, 'SendCadImg', FILTER_SANITIZE_STRING);

if ($SendCadImg) {
    //Receber os dados do formulário
$nome = mysqli_real_escape_string($conexao, trim($_POST['nome']));
$desc = mysqli_real_escape_string($conexao, trim($_POST['desc']));
$banner = mysqli_real_escape_string($conexao, trim($_FILES['banner']['name']));
$id = mysqli_real_escape_string($conexao, trim($_SESSION['id']));
$comunidade = "SIM"; 


   //var_dump($_FILES['banner']);
    //Inserir no BD
            
    $sql = "INSERT INTO comunidade (id_criador, nome, descricao, banner ) VALUES ('$id', '$nome', '$desc','$banner'); ";
    $conexao->query($sql);
    $conexao->close();


    echo " $id, /$nome/ $desc/ $banner/ $id/$comunidade";
    echo "é nois";
 
    $result = "UPDATE usuario SET comunidade = (:comunidade) WHERE id = $id ";
    $result = $conn->prepare($result);
    $result->bindParam(':comunidade', $comunidade);
    //Verificar se os dados foram inseridos com sucesso
     if ($result->execute()) {

        //Recuperar último ID inserido no banco de dados
        $ultimo_id = $id;
        //Diretório onde o arquivo vai ser salvo
        $diretorio = 'imagens/' . $ultimo_id.'/';

        //Criar a pasta de foto 
        mkdir($diretorio, 0755);
        move_uploaded_file($_FILES['banner']['tmp_name'], $diretorio.$banner);
     
        
        if(move_uploaded_file($_FILES['imagem']['tmp_name'], $diretorio.$nome_imagem)){
            $_SESSION['msg'] = "<p style='color:green;'>Dados salvo com sucesso e upload da imagem realizado com sucesso</p>";
            header("Location: editPerfil.php");
        }else{
            $_SESSION['msg'] = "<p><span style='color:green;'>Dados salvo com sucesso. </span><span style='color:red;'>Erro ao realizar o upload da imagem</span></p>";
            header("Location: ../comunidade/comunidade.php");
        }        
    } else {
        $_SESSION['msg'] = "<p style='color:red;'>Erro ao salvar os dados</p>";
        header("Location: perfil.php");
    }
} else {
    $_SESSION['msg'] = "<p style='color:red;'>Erro ao salvar os dados</p>";
    header("Location: Perfil.php");
}
