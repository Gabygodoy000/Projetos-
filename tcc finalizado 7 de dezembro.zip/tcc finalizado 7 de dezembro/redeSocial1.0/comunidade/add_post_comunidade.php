<?php 
session_start();
include('../login/verifica_login.php');
include_once '../Conexao\conexao.php';

$pasta = "../login/imagens";

$id = $_SESSION['id'];


//$consultaa = "SELECT * FROM games_usuario INNER JOIN usuario ON games_usuario.id_usuario = usuario.id INNER JOIN games ON games_usuario.id_game = games.id WHERE id_usuario =$id"; 
//$cona = $conexao->query($consultaa) or die ($mysqli->error);

?>
<!DOCTYPE html>
<html>
<head>
  <title>Games Stars</title>
<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../perfil/cs.css">


  </head>
  <body>
<?php include_once'../view/navbar.php'; ?>

<!-- body -->
<div class="container">
   <div class="row">
      <div class="col-md-12">
         <div id="content" class="content content-full-width">
            <!-- begin profile -->
            <div class="profile">
               <div class="profile-header">
                  <!-- BEGIN profile-header-cover -->
                  <!-- END profile-header-cover -->
                  <!-- BEGIN profile-header-content -->
                
                     <!-- BEGIN profile-header-img -->
                    
                     
                          
                     <!-- END profile-header-img -->
                     <!-- BEGIN profile-header-info -->

                  
                     <!-- END profile-header-info -->
                 
              <form method="POST" action="../post/postar_comunidade.php" enctype="multipart/form-data">
               <div class="bioEdit">
                <h1>foto de post</h1>
                <p>coloque uma foto para os que os usuario vejam</p>
                  <div class="btn-edit"><input type="file" name="banner"></div>
               </div>
               <br>
                <br>
                <div class="bioEdit">
                <h1 class="m-b-10">legenda do post</h1>
                <p>Adicione uma pequena legenda para que os usuario vejam </p>
                <input type="text" name="desc" >
                </div>
                <br>
            <div class="btn">
                 <p>Após ter preenchido todos os campo com seus dados de usuario clique no botão enviar</p>
                 <input name="SendCadImg" class="btn btn-success" type="submit" name="enviar">
            </div>
            </form>
            <br>
          </div>  
            </div>
            <!-- end profile -->
            <!-- begin profile-content -->
          
                  <!-- end #profile-post tab -->
               </div>
               <!-- end tab-content -->
            </div>
            <!-- end profile-content -->
         </div>
      </div>
 
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
