<?php 
session_start();
include('../login/verifica_login.php');
include_once '../Conexao\conexao.php';



$id = $_SESSION['id'];

$consulta = "SELECT * FROM usuario WHERE id = '$id'"; 
$con = $conexao->query($consulta) or die ($mysqli->error);

 

while($info = $con->fetch_array()){
  $resultado = $info['comunidade'];

};

if( $resultado == "NAO") {
?>
<!DOCTYPE html>
<html>
<head>
  <title>Games Stars</title>
<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    

  </head>
  <body>
  
  <div class="logo">
      <h10>Games Stars</h10>
    </div>
    
    <div class="container">
    <div class="navigation">
  <div class="logo">
    <a class="no-underline" href="../login/painel.php">
      Gamer Stars
    </a>
  </div>
  <div class="fotofeed">

  </div>
  <div class="navigation-search-container">
    <i class="fa fa-search"></i>
    <input class="search-field" type="text" placeholder="Search">
    <div class="search-container">
      <div class="search-container-box">
        <div class="search-results">

        </div>
      </div>
    </div>
  </div>
  <div class="icones">
   
  <a href="../chat/user.php" > <img src="../icons/mensagem.png"></a>
    
    <a href="../comunidade/comunidade.php"> <img src="../icons/comunidade.png"></a>

    <a href="../configurracao/configurracao.php"> <img src="../icons/config.png"></a>

    <a href="../login/logout.php"> <img src="../icons/sair.png"></a>
    
    </div>
        </div>
      </i>
    </a>
    
  </div>
</div>
<link rel="stylesheet" type="text/css" href="../perfil/cs.css">

<div class="backcomu">
               
    <div class="criarcomu">
<h4>Deseja criar comunidade?</h4>
</div> 
<div class="txtcomunidade">
<p>Olá voce que deseja criar uma comunidade, é permitido criar uma comunidade por usuario para evitar conflitos</p>
<p>para criar uma comunidade basta clicar no botao abaixo e preencher com o dados que voce queira na sua comunidade</p>
<a href="criarComunidade.php"><button type="button" class="btn btn-success">Criar comunidade</button></a>
</div>
</div>
</div>
<!-- script -->

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
  <?php  
  }
else{

$pasta = "../perfil/imagens";

$id = $_SESSION['id'];

$consulta = "SELECT * FROM comunidade WHERE id_criador = $id"; 
$con = $conexao->query($consulta) or die ($mysqli->error);

while($info = $con->fetch_array()){

  $bio = $info['descricao'];
  $nome = $info['nome'];
  $banner = $info['banner'];

};
$consulta = "SELECT * FROM usuario WHERE id = $id"; 
$con = $conexao->query($consulta) or die ($mysqli->error);

while($info = $con->fetch_array()){

  $nome_criador = $info['nome'];
  $perfil_criador = $info['nome_imagem'];

};

?>

<!DOCTYPE html>
<html>
<head>
  <title>Games Stars</title>

<!-- Required meta tags -->

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../perfil/cs.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
  </head>
  <body> 

<?php include_once'../view/navbar.php'; ?>

<!-- corpo perfil-->

<div class="container">
   <div class="row">
      <div class="col-md-12">
         <div id="content" class="content content-full-width">
            <!-- begin profile -->
            <div class="profile"> 
               <div class="profile-header">
                  <!-- BEGIN profile-header-cover -->
                  <div class="profile-header-cover ">
                    <?php  echo "<img src= $pasta/$id/$banner>";  ?>
                  </div>
                  <div class="Profile-principal">
                  <!-- END profile-header-cover -->
                  <!-- BEGIN profile-header-content -->
                  <div class="profile-header-content">
                     <!-- BEGIN profile-header-img -->

                     <!-- END profile-header-img -->
                     <!-- BEGIN profile-header-info -->
                     <div class="profile-header-info">
                        <h4 class="m-t-10 m-b-5"><?php echo $nome;?></h4>
                        <p class="m-b-10"><?php   echo "$bio"; ?></p>     
                     </div>

                     <div class="profile-games-titulo"> 
                         <div class="nicks"><img class="icons-profile"<?php  echo "src=$pasta/$id/$perfil_criador"; ?>> <?php echo " $nome_criador"; ?> </div>
                         <br> 
                     </div>
                   </div>
                     <!-- END profile-header-info -->
                  </div>


                  <!-- END profile-header-content -->
                  <!-- BEGIN profile-header-tab -->
                  <ul class="profile-header-tab nav nav-tabs">
                     <li class="nav-item"><a href="add_post_comunidade.php">ADICIONAR POST NA COMUNIDADE</a></li>
                     <li class="nav-item"><a href="#profile-photos" class="nav-link" data-toggle="tab">FOTOS</a></li>
                     <li class="nav-item"><a href="#profile-friends" class="nav-link" data-toggle="tab">SEGUIDORES</a></li>
                     <li class="nav-item"><a href="editPerfil.php" class="nav-link">EDITAR COMUNIDADE</a></li>
                  </ul>
                  <!-- END profile-header-tab -->

               </div>
                            
                <div class="profile-comunidade">
                  <br>
                  <center>
                  <div class="gameslegenda2"> 
                  <center><h4>POST</h4></center>
                  </div>
                  <br>  
                  
                  </div>  
            </div>
            <!-- end profile -->
            <!-- begin profile-content -->
          
                  <!-- end #profile-post tab -->
               </div>
               <!-- end tab-content -->
            </div>
            <!-- end profile-content -->
         </div>
         </div>
      </div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
<?php 
}
?>