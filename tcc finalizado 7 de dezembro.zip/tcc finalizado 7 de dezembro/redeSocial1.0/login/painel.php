<?php
session_start();
include('verifica_login.php');
include('../conexao/conexao.php');


$id = $_SESSION['id'];
$consulta = "SELECT * FROM usuario WHERE id = $id";
$con = $conexao->query($consulta) or die($mysqli->error);

while ($info = $con->fetch_array()) {
  $img = $info['nome_imagem'];
};
$diretorioPerfil = "../perfil/imagens/$id/$img";
?>

<?php
$sql = mysqli_query($conexao, "SELECT * FROM usuario WHERE id = {$_SESSION['id']}");
if (mysqli_num_rows($sql) > 0) {
  $row = mysqli_fetch_assoc($sql);
  $id_img = $row['id'];
  $img = $row['nome_imagem'];
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>Games Stars</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="../perfil/cs.css">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">

  <script src="https://unpkg.com/blip-chat-widget" type="text/javascript"></script>
  <script type="text/javascript">
    var openBlipChat;
    window.onload = function() {

      const appkey = "Ym90MnVyb3V0ZXI6ZDVlYjIzMmItYjk3MC00N2IwLTgxNDEtNTg0NjkyOTAyMDUx"; //ALTERE AQUI PARA O SEU CÓDIGO DO CHAT WIDGET BLIP

      var client = new BlipChat()
        .withAppKey(appkey)
        .withEventHandler(BlipChat.LOAD_EVENT, function() {
          var iframe = document.getElementById("blip-chat-iframe");
          iframe.contentWindow.postMessage({
            code: "ShowCloseButton",
            showCloseButton: true
          }, iframe.src);
        });

      client.build();

      openBlipChat = function() {
        client.widget._openChat();
      }
    }

    function actionToggle() {
      var action = document.querySelector('.action');
      action.classList.toggle('active');
    }

    function showdiv() {
      document.getElementById("alert").style.visibility = "visible";
    }
    setTimeout("showdiv()", 5000);

    function hidediv() {
      document.getElementById("alert").style.visibility = "hidden";
    }
    setTimeout("hidediv()", 50000);
  </script>
</head>

<body>

  <div class="container">
    <div class="navigation">
      <div class="logo">
        <a class="no-underline" href="../login/painel.php">
          Gamer Stars
        </a>
      </div>
      <div class="navigation-search-container">
        <i class="fa fa-search"></i>
        <form action="../pesquisa/perfilpesquisa.php" method="post">
          <input class="search-field" name="nome" type="text" placeholder="Search">
        </form>
        <div class="search-container">
          <div class="search-container-box">
            <div class="search-results">

            </div>
          </div>
        </div>
      </div>
      <div class="icones">

        <a href="../chat/user.php"> <img src="../icons/mensagem.png" title="Mensagens" class="img"></a> 

        <a href="../configurracao/configurracao.php"> <img src="../icons/config.png" title="Configurações" class="img"></a>

        <a href="../login/logout.php"> <img src="../icons/sair.png" title="Sair" class="img"></a>

        <a href="../perfil/perfil.php"> <img src="<?php echo $diretorioPerfil; ?>" alt="perfil" title="Perfil" class="fotofeed"></a>

 
      </div>

    </div>
    </i>
    </a>

  </div>
  </div>
  <div class="action" onclick="actionToggle();">
    <span>|</span>
    <ul>
      <li><a href="/redeSocial1.0/chat/user.php" onclick="openBlipChat()"><img src="https://bots2u.com.br/chat-widget/icons/blip-full.png" width="16" height="16">Chat</a></li>
    </ul>
  </div>
  <div class="container">
    <div class="feed">
      <div class="addpost">
        <div class="">
          <center>
            <br>
            <h1>Adicionar publicação</h1>
            <form method="POST" action="../post/postar_perfil.php" enctype="multipart/form-data">
              <div class="legendpost">
                <input type="text" maxlength="100" placeholder="Adicione uma Legenda" name="desc">
              </div>
          </center>
          <div class="imgpost">
            <label class="myLabel">
              <input type="file" name="banner" required />
              <span>Escolha uma Foto/Imagem para postar.</span>
            </label>
          </div>
          <br>
          <div class="btn-publi">
            <input name="SendCadImg" class="btn btn-success" type="submit" name="enviar">
          </div>
          </form>
        </div>
        <center><?php include_once '../post/post.php' ?></center>
      </div>
    </div>
  </div>
  </div>
  <!-- script -->

  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->

  <script src="../js/curtir.js"></script>
  <script src="../js/comentar.js"></script>

  </div>
  </div>
</body>

</html>