
<?php 
 session_start();
 include_once '../conexao/conexao.php';

 $id = $_SESSION['id'];

 $consulta = "SELECT * 	FROM usuario WHERE id= $id;"; 
 $con = $conexao->query($consulta) or die ($mysqli->error);

 while($info = $con->fetch_array()){
 $resul = $info['primeiro_acesso'];
}
 $result = $resul;
 $acesso = "NAO";


if ($acesso == $result ) {
	header("Location: ../login/painel.php");
}
if ($acesso != $result ) {

    for ($i = 1 ; ; $i++) {

    $result_img = "INSERT INTO usuario (game1, game2, game3, game4, game5 ) VALUES ('1', '1', '1', '1', '1') WHERE id = $id";
    $insert_msg = $conn->prepare($result_img);
    $insert_msg-> execute();         

    	if ($i >= 5) {

    	 $result = "UPDATE usuario SET primeiro_acesso = (:acesso) WHERE id = $id";
         $insert_ms = $conn->prepare($result);
         $insert_ms->bindParam(':acesso', $acesso);
         $insert_ms-> execute();  

    	header('Location: ../acesso.php');
        break;
		exit;
	}
}
}
 ?>