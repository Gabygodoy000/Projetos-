<?php
session_start();
include("../conexao/conexao.php");

$nome = mysqli_real_escape_string($conexao, trim($_POST['nome']));
$usuario = mysqli_real_escape_string($conexao, trim($_POST['usuario']));
$senha = mysqli_real_escape_string($conexao, trim(md5($_POST['senha']))); 
$email = mysqli_real_escape_string($conexao, trim($_POST['email']));
$senha2 = mysqli_real_escape_string($conexao, trim(md5($_POST['senha2'])));
$acesso = "SIM";
$comunidade = "NAO";


$sql = "select count(*) as total from usuario where usuario = '$usuario'";
$result = mysqli_query($conexao, $sql);
$row = mysqli_fetch_assoc($result);

$sql1 = "select count(*) as total1 from usuario where nome = '$nome'";
$result1 = mysqli_query($conexao, $sql1);
$row1= mysqli_fetch_assoc($result1);

if($row['total'] == 1) {
	$_SESSION['nao_autenticado'] = true;
	header('Location: registra.php');
	exit();
}

if($row1['total1'] == 1) {
	$_SESSION['nome_autenticado'] = true;
	header('Location: registra.php');
	exit();
}

if($senha != $senha2){
  	$_SESSION['senha_invalida'] = true;
	header('Location: registra.php');
	exit();
}
$sql = "INSERT INTO usuario (nome, usuario, senha, email, primeiro_acesso, comunidade ) VALUES ('$nome', '$usuario', '$senha', '$email','$acesso','$comunidade') ";

if($conexao->query($sql) === TRUE) {
	$_SESSION['status_cadastro'] = true;
}

$conexao->close();

header('Location: ../index.php');
exit;
?>