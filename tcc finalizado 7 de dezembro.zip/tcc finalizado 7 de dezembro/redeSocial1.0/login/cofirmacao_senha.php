<?php 
session_start();
include('../conexao/conexao.php');

$email = mysqli_real_escape_string($conexao, trim($_POST['email']));

$sql = "select count(*) as total from usuario where usuario = '$email'";
$result = mysqli_query($conexao, $sql);
$row = mysqli_fetch_assoc($result);

if($row['total'] == 0) {
	$_SESSION['nao_autenticado'] = true;
	header('Location: esqueceu_senha.php');
	exit();
}
else{
    $id = $pdo->lastInsertEmail();
    $md5 = md5($id);

    $assunto = " Olá se foi você que perdiu pra renovar a senha clique no link a abaixo, se a caso não foi voce clique mesmo assim para sua propria segurança ou apenas ignore";

    $link = "http://localhost/RedeSocial1.0/login/senha.php".$md5;

    $mensagem = "Clique aqui para renovar sua senha".$link;

    $header = "From: gamer";

    mail($email, $assunto, $mensagem, $header);

	header('Location: ../index.php');
	exit();
}

?>
