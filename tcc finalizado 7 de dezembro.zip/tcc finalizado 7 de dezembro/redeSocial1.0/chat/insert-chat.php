<?php 
    session_start();
    if(isset($_SESSION['id'])){
        include_once "../conexao/conexao.php";
        $outgoing_id = $_SESSION['id'];
        $incoming_id = mysqli_real_escape_string($conexao, $_POST['id_para']);
        $message = mysqli_real_escape_string($conexao, $_POST['mensagem']);
        
        
    
        if(!empty($message)){
            $sql = mysqli_query($conexao, "INSERT INTO mensagem (id_usuario, id_para, msg)
                                        VALUES ({$incoming_id}, {$outgoing_id}, '{$message}')") or die();
        }
    }


    
?>