<?php
    while($row = mysqli_fetch_assoc($query)){
        $sql2 = "SELECT * FROM mensagem WHERE (id_usuario = {$row['id']}
                OR id_para = {$row['id']}) AND (id_para = {$id_para} 
                OR id_usuario = {$id_para}) ORDER BY msg_id DESC LIMIT 1";
        $query2 = mysqli_query($conexao, $sql2);
        $row2 = mysqli_fetch_assoc($query2);
        (mysqli_num_rows($query2) > 0) ? $result = $row2['msg'] : $result ="Não há mensagens";
        (strlen($result) > 28) ? $msg =  substr($result, 0, 28) . '...' : $msg = $result;
        if(isset($row2['id_para'])){
            ($id_para == $row2['id_para']) ? $you = "Você:" : $you = "";
        }else{
            $you = "";
        }
        ($row['status'] == "Offline now") ? $offline = "offline" : $offline = "";
        ($id_para == $row['id']) ? $hid_me = "hide" : $hid_me = "";

        $output .= '<a href="chat.php?user_id='. $row['id'] .'">
                    <div class="content">
                    <img src="../perfil/imagens/'. $row['id'] .'/'.$row ['nome_imagem'].'" alt="">
                    <div class="details">
                        <span>'. $row['nome'].'</span>
                        <p>'. $you . $msg .'</p>
                    </div>
                    </div>
                    <div class="status-dot '. $offline .'"><i class="fas fa-circle"></i></div>
                </a>';
    }
?>