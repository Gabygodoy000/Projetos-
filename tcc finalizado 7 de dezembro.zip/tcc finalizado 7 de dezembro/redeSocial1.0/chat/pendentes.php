<?php
session_start();
require "../conexao/conexao.php";

$id = $_SESSION['id'];


    $buscar = $conn->prepare("SELECT * FROM seguidores INNER JOIN usuario ON seguidores.id_seguidor = usuario.id  WHERE id_usu= 109 ");
    $buscar->execute();
    $size = $buscar->rowCount();
   
    if($size > 0) {
        while($linha = $buscar->fetch(PDO::FETCH_ASSOC)){
            $nome = $linha['nome'];
            $perfil = $linha ['nome_imagem'];
            $idusu = $linha ['id_seguidor'];
            $diretorio = "../perfil/imagens/$idusu/$perfil";

         ?>
         <link rel="stylesheet" type="text/css" href="../perfil/cs.css">
         <divc class="chat">
         <a href="#" para="para" parausu="<?php echo $idusu ?>">
         <div>
         <img src="<?php echo"$diretorio" ;?>" alt="perfil">
         <p><?php echo $nome?></p>
         </div>
         </a>
         </div>
         <script src="../js/jquery.js"></script>
         <script src="../js/pendentes.js"></script>
         <?php
        }
    } else {
    echo "<p>OPS! vc n possui nenhuma mensagem ".$nome ."</p>";
    echo "<p> deseja iniciar conversa com algm? </p>";
    }
