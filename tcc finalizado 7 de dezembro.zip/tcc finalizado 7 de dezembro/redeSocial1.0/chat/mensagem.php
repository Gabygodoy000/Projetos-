<?php

    include_once '../conexao/mensagemDAO.php';
    date_default_timezone_set('America/Sao_Paulo');

    $para= $_POST['para'];
    $usuario = $_POST['usuario'];
    $mensagem = $_POST['mensagem'];
    $hora = date('H:i:s');

    echo $hora;
    
     $mensagemDao = new mensagemDAO  ();
    
     $res = $mensagemDao->inserir($usuario,$mensagem,$para,$hora);
     if ($res == false) {
        echo json_encode("falha ao tentar comentar!");
     } else{
         echo json_encode("deu certo");
     }
     
?>  