<?php

    include_once '../conexao/conexao.php';

    $para = $_POST['para'];
    $hora = date('H:i:s');

    echo $hora;
    
     $mensagemDao = new mensagemDAO  ();
    
     $res = $mensagemDao->inserir($usuario,$mensagem,$para,$hora);
     if ($res == false) {
        echo json_encode("falha ao tentar comentar!");
     } else{
         echo json_encode("deu certo");
     }
     
?>  