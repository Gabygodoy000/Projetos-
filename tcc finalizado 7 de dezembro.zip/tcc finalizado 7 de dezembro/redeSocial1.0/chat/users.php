<?php
    session_start();
    include_once "../conexao/conexao.php";
    $id_para= $_SESSION['id'];
    
    $sql = "SELECT * FROM usuario WHERE NOT id = {$id_para} ORDER BY id DESC";
    $query = mysqli_query($conexao, $sql);
    $output = "";
    if(mysqli_num_rows($query) == 0){
        $sql2 = "SELECT * FROM seguidores INNER JOIN usuario ON seguidores.id_seguidor = usuario.id  WHERE id_seguidor = $id ";
        $query2 = mysqli_query($conexao, $sql);
        
        if(mysqli_num_rows($query2) == 0){
            $output .= "nenhum usuario para iniciar conversa";
        }elseif(mysqli_num_rows($query2) > 0){
            include_once "data.php";
        }
    }elseif(mysqli_num_rows($query) > 0){
        include_once "data.php";
    }
    echo $output;
?>