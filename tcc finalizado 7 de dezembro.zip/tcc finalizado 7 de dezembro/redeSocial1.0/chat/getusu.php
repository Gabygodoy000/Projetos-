<?php

$para = $_POST['para'];

 echo "$para";
 
?>