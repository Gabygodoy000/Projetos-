<?php
session_start();
include('../login/verifica_login.php');
include_once '../Conexao/conexao.php';


$id = $_SESSION['id'];

$consulta = "SELECT * FROM mensagem WHERE id_usuario = $id"; 
$con = $conexao->query($consulta) or die ($mysqli->error);

while($info = $con->fetch_array()){
  $id_para = $info['id_para'];
};  
    $buscar = $conn->prepare("SELECT * FROM seguidores INNER JOIN usuario ON seguidores.id_seguidor = usuario.id  WHERE id_usu= $id ");
    $buscar->execute();
    $size = $buscar->rowCount();
?>
<!DOCTYPE html>
<html lang="pt-br">

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../perfil/cs.css">
    <script src="../js/jquery.js"></script>
    <script src="../js/mensagem.js"></script>
    <script src="../js/pendentes.js"></script>

    <title>Games Stars</title>
  </head>
<body>
  <?php include_once'../view/navbar.php'; ?>
  <nav class="navbar navbar-light bg-light">
  <form class="form-inline" action="pesquisar.php" method="POST">
    <input class="form-control mr-sm-2" type="search" name="nome" placeholder="Pesquisar" aria-label="Pesquisar">
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Pesquisar</button>
  </form>
</nav>
<div></div>

  <div>
    <div class="chats">
      <div id="chat">

      </div>
    </div>
  <script type="text/javascript">

    $(document).ready(function(){
      $('#mensagens').load("mensagem.php");
      
      var refreshId = setInterval(function(){
        $('#mensagens').load("mensagem.php");
      }, 750);
      
      $.ajaxSetup({
        cache:false
      });
    });
  </script>
  </div>
 

  <div class="wrapper">
    <section class="chat-area">
      <header>
        <?php 
          $id = mysqli_real_escape_string($conn, $_GET['id']);
          $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$id}");
          if(mysqli_num_rows($sql) > 0){
            $row = mysqli_fetch_assoc($sql);
          }
        ?>
        <a href="users.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
        <img src="php/images/<?php echo $row['img']; ?>" alt="">
        <div class="details">
          <span><?php echo $row['fname']. " " . $row['lname'] ?></span>
          <p><?php echo $row['status']; ?></p>
        </div>
      </header>






        
  <div class="chat-box">

</div>
<form action="#" class="typing-area">
  <input type="text" class="incoming_id" name="incoming_id" value="<?php echo $id; ?>" hidden>
  <input type="text" name="message" class="input-field" placeholder="Type a message here..." autocomplete="off">
  <button><i class="fab fa-telegram-plane"></i></button>
</form>
</section>
</div>

  <div id="mensagens">
  </div>
  <form id="mensagem_forms">   
    <input type="text"  id="mensagem" placeholder="Digite uma mensagem." maxlength="50" autocomplete="off"/>
  </form>
  <button type="button"  class="btn btn-primary" id="enviamensagem" usuario="<?php echo $id ?>" para="<?php echo $id?>">enviar mensagem</button>
</body>

</html>
