<?php
session_start();
include_once "../conexao/conexao.php";
$id = $_SESSION['id'];
?>
<?php include_once "header.php"; ?>
<link rel="stylesheet" type="text/css" href="../perfil/cs.css">
<html>

<body>
  <div class="container">
    <div class="textofundochats">
      <p>GAMES STARS</p>
      <div class="wrapper">
        <div class="iconchats">
          <a href="../login/painel.php"> <img src="../icons/voltar.png"></a>
        </div>
        <section class="users">
          <header>
            <div class="content">
              <div class="details2">
                <center>
                  <span><img src="../icons/perfil.png" alt=""></span>
                </center>
                <p><?php echo "Chat" ?></p>
              </div>
            </div>
          </header>
          <div class="search">
            <span></span>
            <input></input>
            <button></button>
          </div>
          <div class="users-list">
          </div>
        </section>
      </div>
    </div>
    <script src="../js/users.js"></script>


    <div class="wrapper2">
      <div class="iconchat">
        <a href="../chat/user.php"> <img src="../icons/voltar.png"></a>
      </div>
      <section class="chat-area">
        <div class="details">
        </div>
        </header>
        <div class="chat-box">
        </div>
        <form action="#" class="typing-area">
        </form>
      </section>


    </div>
    <div class="action2">
      <span><a href="../perfil/perfil.php"><img src="../icons/perfil.png" alt=""></span>
      <ul>
      </ul>
    </div>
</body>

</html>