<?php

$dbusername = 'root';
$dbuserpass = '';
$dbhost= 'localhost';
$dbname = 'tccredesocial';

$var = "mysql:host=" . $dbhost . ";dbname=" . $dbname . ";";
$con = new PDO($var, $dbusername, $dbuserpass);