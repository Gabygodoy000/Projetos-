<?php

require "config.php";

if (isset($_COOKIE['nome'])) {
    $nome = $_COOKIE['nome'];
    $buscar = $con->prepare("SELECT * FROM seguidores ;");
    $buscar->execute();
    $size = $buscar->rowCount();
   
    if($size > 0) {
        while($linha = $buscar->fetch(PDO::FETCH_ASSOC)){
        

        
        }
    } else {
    echo "<p>Seja bem-vindo ".$nome ."</p>";
    echo "<p> Não há mensagem por enquanto </p>";
    }
  
}