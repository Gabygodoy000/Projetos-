<?php
	$nome = $_POST['nome'];

	include_once '../Conexao\conexao.php';

    $consulta = "SELECT * FROM usuario WHERE nome = '$nome'"; 
	$con = $conexao->query($consulta) or die ($mysqli->error);

 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>ksks</title>
 </head>
 <body>
 	<div>
 	<?php 	foreach($info = $con->fetch_array()){?>
      <?php echo "$nome2 = $info['nome']"	;
 	} ?>
 </div>
 </body>
 </html>