<?php 
    session_start();
    if(isset($_SESSION['id'])){
        include_once "../conexao/conexao.php";
        $id_para = $_SESSION['id'];
        $id = mysqli_real_escape_string($conexao, $_POST['id_para']);
        $output = "";
        $sql = "SELECT * FROM mensagem LEFT JOIN usuario ON usuario.id = mensagem.id_para
                WHERE (id_para = {$id_para} AND id_usuario = {$id})
                OR (id_para = {$id} AND id_usuario = {$id_para}) ORDER BY msg_id";
        $query = mysqli_query($conexao, $sql);
        if(mysqli_num_rows($query) > 0){
            while($row = mysqli_fetch_assoc($query)){
                if($row['id_para'] == $id_para){
                    $output .= '<div class="chat outgoing">
                                <div class="details">
                                    <p>'. $row['msg'] .'</p>
                                </div>
                                </div>';
                }else{
                    $output .= '<div class="chat incoming">

                                <div class="details">
                                    <p>'. $row['msg'] .'</p>
                                </div>
                                </div>';
                }
            }
        }else{
            $output .= '<div class="text">Não há mensagens disponíveis</div>';
        }
        echo $output;
    }

?>