<?php
session_start();
include_once "../conexao/conexao.php";
$id = $_SESSION['id'];

?>
<link rel="stylesheet" type="text/css" href="../perfil/cs.css">

<body>
  <div class="container">
    <div class="textofundochats">
      <p>GAMES STARS</p>
      <div class="wrapper">
        <div class="iconchats">
          <a href="../login/painel.php"> <img src="../icons/voltar.png"></a>
        </div>
        <section class="users">
          <header>
            <div class="content">
              <div class="details2">
                <center>
                  <span><img src="../icons/perfil.png" alt=""></span>
                </center>
                <p><?php echo "Chat" ?></p>
              </div>
            </div>
          </header>
          <div class="search">
            <span></span>
            <input></input>
            <button></button>
          </div>
          <div class="users-list">
          </div>
        </section>
      </div>
    </div>
    <script src="../js/users.js"></script>

    <div class="wrapper2">
      <div class="iconchat">
        <a href="../chat/user.php"> <img src="../icons/voltar.png"></a>
      </div>
      <section class="chat-area">
        <header>
          <?php
          $user_id = mysqli_real_escape_string($conexao, $_GET['user_id']);
          $sql = mysqli_query($conexao, "SELECT * FROM usuario WHERE id = {$user_id}");
          if (mysqli_num_rows($sql) > 0) {
            $row = mysqli_fetch_assoc($sql);
            $id_img = $row['id'];
            $img = $row['nome_imagem'];
          } else {
            header("location: users.php");
          }

          ?>

          <a href="users.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
          <img src="../perfil/imagens/<?php echo "$id_img/$img"; ?>" alt="">
          <div class="details">
            <span><?php echo $row['nome'] . " " ?></span>
          </div>
        </header>
        <div class="chat-box">

        </div>
        <form action="#" class="typing-area">
          <input type="text" class="id_para" name="id_para" value="<?php echo $user_id; ?>" hidden>
          <input type="text" name="mensagem" class="input-field" placeholder="escreva uma mensagem" autocomplete="off">
          <button><i class="fab fa-telegram-plane"></i><img src="../icons/enviar.png" /></button>
        </form>
      </section>
    </div>
    <div class="action2">
      <span><a href="../perfil/perfil.php"><img src="../icons/perfil.png" alt=""></span>
      <ul>
      </ul>
    </div>

    <script src="../js/chat.js"></script>

</body>

</html>