<?php
require "config.php";

date_default_timezone_set('America/Sao_Paulo');

    $para = "ksksk";
if (isset($_COOKIE['nome'])) {
    $nome = strip_tags($_COOKIE['nome']);
    $mensagem = htmlspecialchars($_POST['mensagem']);
    $hora = date('H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'];

    echo "$para/$nome/$mensagem/$hora/$ip";

    $sql = $con->prepare("INSERT INTO mensagem (id_usuario, id_para, mensagem, hora, ip) value(:id_usuario,:id_para, :mensagem, :hora, :ip)");
    $sql->bindValue(":id_usuario", $nome);
    $sql->bindValue(":mensagem", $mensagem);
    $sql->bindValue(":hora", $hora);
    $sql->bindValue(":ip", $ip);
    $sql->bindValue(":id_para",$para);
    $sql->execute();
}