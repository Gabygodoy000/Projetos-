<?php 
include_once '../Conexao/conexao.php';

$pasta = "../perfil/imagens";

$id = $_SESSION['id'];

$consulta = "SELECT * FROM usuario WHERE id = $id"; 
$con = $conexao->query($consulta) or die ($mysqli->error);

while($info = $con->fetch_array()){
  $img = $info['nome_imagem'];

};

$diretorioPerfil = "../perfil/imagens/$id/$img";
?>

<div class="logo">
      <h10>Games Stars</h10>
    </div>
    
    <div class="container">
    <div class="navigation">
  <div class="logo">
    <a class="no-underline" href="../login/painel.php">
      Games Stars
    </a>
  </div>
  <div class="fotofeed">
    <img src="<?php echo $diretorioPerfil;?>" alt="perfil">
  </div>
  <div class="navigation-search-container">
    <i class="fa fa-search"></i>
    <input class="search-field" type="text" placeholder="Search">
    <div class="search-container">
      <div class="search-container-box">
        <div class="search-results">

        </div>
      </div>
    </div>
  </div>
  <div class="icones">
   
    <a href="../chat/chat.php" > <img src="../icons/mensagem.png"></a>
    
    <a href="../comunidade/comunidade.php"> <img src="../icons/comunidade.png"></a>

    <a href="../login/logout.php"> <img src="../icons/sair.png"></a>
  
    <div class="container">
    <div class="navigation">
  <div class="logo">
    <a class="no-underline" href="../login/painel.php">
      Games Stars
    </a>
  </div>
  <div class="fotofeed">
   <a href="../perfil/perfil.php"> <img src="<?php echo $diretorioPerfil;?>" alt="perfil"></a>
  </div>
  <div class="navigation-search-container">
    <i class="fa fa-search"></i>
    <input class="search-field" type="text" placeholder="Search">
    <div class="search-container">
      <div class="search-container-box">
        <div class="search-results">

        </div>
      </div>
    </div>
  </div>
  <div class="icones">
   
    <a href="../chat/chat.php" > <img src="../icons/mensagem.png"></a>
    
    <a href="../comunidade/comunidade.php"> <img src="../icons/comunidade.png"></a>

    <a href="../configurracao/configurracao.php"> <img src="../icons/config.png"></a>

    <a href="../login/logout.php"> <img src="../icons/sair.png"></a>
    
    </div>
        </div>
      </i>
    </a>
    
  </div>
</div>


        </div>
      </i>
    </a>
    
  </div>
</div>
