$(document).ready(function(){
    $('#enviamensagem').click(function(){

        let usuario = $(this).attr('usuario');
        let para = $(this).attr('para');
        let mensagem = $('#mensagem').val();
 
        console.log(usuario);
        console.log(para);
        console.log(mensagem);
            
               $.ajax({
                    url:'../chat/mensagem.php',
                    method: 'POST',
                    cache: false,
                    data: {usuario: usuario, para: para, mensagem: mensagem},
                    type: "json",
                }).done(function (result){
                console.log(result);
                usuario = null;
                para = null;
                mensagem = null;
                });
     
    });
})