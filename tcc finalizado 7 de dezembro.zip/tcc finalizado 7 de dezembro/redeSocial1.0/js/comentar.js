$(document).ready(function (){
 $('a[comentar]').click(function(){
 
    let usuario = (this).getAttribute('usuario');
    let post = (this).getAttribute('post');
    let nome= $(this).attr('nome');
    let img = $(this).attr('img');

    console.log(nome);
    console.log(img);
   
    $('#exampleModal').modal('show');

   $("#comentComfirm").click(function (){
      let comentario = $('#comentar').val();
      $.ajax({
          url:'../post/comentar.php',
          method: 'POST',
          cache: false, 
          data: {usuario: usuario, post: post, comentario: comentario, nome: nome, img: img},
          Datatype: "json",
         success: function(data){
            $('#comenttmp').css({'background':"#02ff3a;"});
            $('#comenttmp').html(data);
        },error: function(){
            $('#comenttmp').css({'background':"#f00"});
            $('#comenttmp').html('ouve um erro');
        }
      }).done(function (result){
         console.log(result);
         comentario = null;
         post = null;
         usuario = null;
      });
      $('#comentar-form').trigger("reset");
   });

   $('#exampleModal').on('hidden.bs.modal', function (){
      $('#comentar-form').trigger("reset");
      $('#comenttmp').trigger("reset");
      $('#lista-comentario').empty();
   });

   $.ajax({
      url: '../post/listar-comentario.php',
      method: 'POST',
      data: {post: post},
      dataType: 'json'
   }).done(function (result){
      for (let i = 0; i < result.length; i++){
         console.log(result);
         $('#lista-comentario').prepend("<img src='../perfil/imagens/"+result[i].id + "/" + result[i].nome_imagem + "' width='50px'><p '>"+ result[i].nome +":"+ result[i].comentario + "</p>");

         $('#exampleModal').on('hidden.bs.modal', function (){
            result = "";
         });
      }
   });
 return false;
 });
});
