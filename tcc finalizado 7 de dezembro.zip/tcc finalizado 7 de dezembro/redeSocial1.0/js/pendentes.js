$(document).ready(function (){
    $('a[para]').click(function(){
    
        let para = $(this).attr('parausu');
  
        console.log(para);
        $.ajax({
            url:'../chat/getusu.php',
            method: 'POST',
            cache: false,
            data: { para: para},
            type: "json",
        }).done(function (result){
        console.log(result);
        usuario = null;
        para = null;
        });

    });
   });
   