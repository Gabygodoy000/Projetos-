$(document).ready(function (){
    $('#seguir').click(function(){
    
       let usuarioSeguir = $(this).attr('usuarioSeguir');
       let usuarioSeguir2 = $(this).attr('usuarioSeguir2');
       console.log(usuarioSeguir);
       console.log(usuarioSeguir2);

       $.ajax({
        url: '../seguidores/seguir.php',
        method: 'POST', 
        data: {usuarioSeguir: usuarioSeguir,usuarioSeguir2: usuarioSeguir2},
        BeforeSend: function()  {
            $('#seguir').html("verificando");
        },success: function(data){
            $('#seguir').css({'background':"#02ff3a;"});
            $('#seguir').html(data);
        },error: function(){
            $('#seguir').css({'background':"#f00"});
            $('#seguir').html('ouve um erro');
        }
        });
    });
 
    $('#deixar').click(function(){
    
        let usuariodeixar2 = $(this).attr('usuario2deixar');
        let usuariodeixar = $(this).attr('usuariodeixar');

        console.log(usuariodeixar2);
        console.log(usuariodeixar);
 
        $.ajax({
         url: '../seguidores/deixar.php',
         method: 'POST',
         data: {usuariodeixar: usuariodeixar,usuariodeixar2:usuariodeixar2},
         BeforeSend: function()  {
            $('#deixar').html("verificando");
        },success: function(data){
            $('#deixar').css({'background':"#02ff3a;"});
            $('#deixar').html(data);
        },error: function(){
            $('#deixar').css({'background':"#f00"});
            $('#deixar').html('ouve um erro');
        }
         });
     });

    
})
