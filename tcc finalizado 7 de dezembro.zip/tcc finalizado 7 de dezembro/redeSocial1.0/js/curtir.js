$(document).ready(function (){
    $('#btn-curtir').click(function (){
        let usuario = $('#btn-curtir').attr('usuario');
        let post = $('#btn-curtir').attr('post');
        let curtida = $('#btn-curtir').attr('curtida');

        console.log(curtida);
        console.log(usuario);
        console.log(post);
        
        $.ajax({
            url: '../post/curtida.php',
            method: 'POST',
            data: {usuario: usuario, post: post, curtida: curtida},
            datatype: 'json',
            BeforeSend: function()  {
            $('#numcurt').html("verificando");
        },success: function(data){
            $('#numcurt').css({'background':"#02ff3a;"});
            $('#numcurt').html(data);
        },error: function(){
            $('#numcurt').css({'background':"#f00"});
            $('#numcurt').html('ouve um erro');
        }
        }).done(function (result){
            console.log(result);
        });
    });
}) 